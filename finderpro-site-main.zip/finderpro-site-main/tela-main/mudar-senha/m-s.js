const changePass = document.getElementById('changePass');

changePass.addEventListener('click', () => {
  window.location.href = 'm-s.html';
});